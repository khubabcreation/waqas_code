package com.example.bloc_by_using_library_counter_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
