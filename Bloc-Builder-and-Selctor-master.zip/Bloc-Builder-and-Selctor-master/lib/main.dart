import 'package:bloc_by_using_library_counter_app/student_bloc/student_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'color_bloc/color_bloc.dart';
import 'bloc/counter_bloc.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home:
          //here i have used the MultiBlocProvider
          MultiBlocProvider(providers: [
        BlocProvider<StudentBloc>(
          create: (context) => StudentBloc(),
        ),
        BlocProvider<ColorBloc>(
          create: (context) => ColorBloc(),
        ),
        BlocProvider<CounterBloc>(
          create: (context) => CounterBloc(),
        )
      ], child: const MyHomePage(title: 'Flutter Demo Home Page')),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  //this is the nice way to do
  late CounterBloc counterBloc;
  late ColorBloc colorBloc;
  late StudentBloc studentBloc;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    counterBloc = context.read<CounterBloc>();
    colorBloc = context.read<ColorBloc>();
    studentBloc = context.read<StudentBloc>();
  }

  void _incrementCounter() {
    context.read<CounterBloc>().add(IncrementCounter());
  }

  void _decrementCounter() {
    context.read<CounterBloc>().add(DecrementCounter());
  }

  void _changeToRed() {
    context.read<ColorBloc>().add(RedColorEvent());
  }

  void _changeToGray() {
    context.read<ColorBloc>().add(GrayColorEvent());
  }

  void _changeName() {
    context.read<StudentBloc>().add(NameEvent());
  }

  void _changeRollNumber() {
    context.read<StudentBloc>().add(RollNumberEvent());
  }

  void _changeAge() {
    context.read<StudentBloc>().add(AgeEvent());
  }

  @override
  Widget build(BuildContext context) {
    print('Main builder method called');
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          title: Text(widget.title),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              BlocBuilder<CounterBloc, CounterState>(
                bloc: counterBloc,
                builder: (context, state) {
                  return Text(
                    '${state.count}',
                    style: Theme.of(context).textTheme.headlineMedium,
                  );
                },
              ),
              BlocBuilder<ColorBloc, ColorState>(
                bloc: colorBloc,
                builder: (context, state) {
                  return Container(
                    height: 200,
                    width: 200,
                    color: state.color,
                  );
                },
              ),
              BlocSelector<StudentBloc, StudentState, int>(
                bloc: studentBloc,
                selector: (state) => studentBloc.state.age,
                builder: (context, state) {
                  print('Age Build method called');
                  return Text(state.toString());
                },
              ),
              BlocSelector<StudentBloc, StudentState, String>(
                bloc: studentBloc,
                selector: (state) => studentBloc.state.name,
                builder: (context, state) {
                  print('name build method called');
                  return Text(state.toString());
                },
              ),
              BlocSelector<StudentBloc, StudentState, int>(
                selector: (state) => studentBloc.state.rollNumber,
                bloc: studentBloc,
                builder: (context, state) {
                  print('Roll number build method build');
                  return Text(state.toString());
                },
              ),
              // BlocBuilder<StudentBloc, StudentState>(
              //   bloc: studentBloc,
              //   builder: (context, state) {
              //     print('Name builder method called');
              //     return Text(state.name);
              //   },
              // ),
              // BlocBuilder<StudentBloc, StudentState>(
              //   bloc: studentBloc,
              //   builder: (context, state) {
              //     print('RollNumber builder method called');
              //     return Text(state.rollNumber.toString());
              //   },
              // ),
              // BlocBuilder<StudentBloc, StudentState>(
              //   bloc: studentBloc,
              //   builder: (context, state) {
              //     print('Age builder method called');
              //     return Text(state.age.toString());
              //   },
              // ),
            ],
          ),
        ),
        floatingActionButton: ButtonBar(
          children: [
            FloatingActionButton(
              onPressed: _incrementCounter,
              tooltip: 'Increment',
              child: const Icon(Icons.add),
            ),
            FloatingActionButton(
              onPressed: _decrementCounter,
              tooltip: 'Decrement',
              child: const Icon(Icons.remove),
            ),
            FloatingActionButton(
              onPressed: _changeToGray,
              tooltip: 'change color to gray',
              splashColor: Colors.grey,
            ),
            FloatingActionButton(
              onPressed: _changeToRed,
              tooltip: 'Change Color to rad',
              splashColor: Colors.red,
            ),
            FloatingActionButton(
              onPressed: _changeAge,
              splashColor: Colors.blue,
              tooltip: "Change Age",
            ),
            FloatingActionButton(
              onPressed: _changeName,
              tooltip: "Change Name",
              splashColor: Colors.blue,
            ),
            FloatingActionButton(
              onPressed: _changeRollNumber,
              splashColor: Colors.blue,
              tooltip: "Change Roll Number",
            ),
          ],
        ));
  }
}
