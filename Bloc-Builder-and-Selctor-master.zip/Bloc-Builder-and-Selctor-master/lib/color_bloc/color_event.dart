part of 'color_bloc.dart';

@immutable
abstract class ColorEvent {}

class RedColorEvent extends ColorEvent {}

class GrayColorEvent extends ColorEvent {}
