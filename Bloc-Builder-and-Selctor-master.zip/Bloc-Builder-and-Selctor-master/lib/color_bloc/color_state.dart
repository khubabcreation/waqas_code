part of 'color_bloc.dart';

@immutable
class ColorState {
  final Color color;
  const ColorState(this.color);
}
