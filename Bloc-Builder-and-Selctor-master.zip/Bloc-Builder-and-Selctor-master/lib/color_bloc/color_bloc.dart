import 'dart:ui';
import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
part 'color_event.dart';
part 'color_state.dart';

class ColorBloc extends Bloc<ColorEvent, ColorState> {
  ColorBloc() : super(const ColorState(Colors.blue)) {
    on<RedColorEvent>((event, emit) => emit(const ColorState(Colors.red)));
    on<GrayColorEvent>((event, emit) => emit(const ColorState(Colors.grey)));
  }
}
