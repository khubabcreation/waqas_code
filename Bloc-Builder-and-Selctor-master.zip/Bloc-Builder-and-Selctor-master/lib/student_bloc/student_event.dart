part of '../student_bloc/student_bloc.dart';

@immutable
abstract class StudentEvent {}

class NameEvent extends StudentEvent {}

class RollNumberEvent extends StudentEvent {}

class AgeEvent extends StudentEvent {}
