part of '../student_bloc/student_bloc.dart';

@immutable
class StudentState {
  final int age;
  final int rollNumber;
  final String name;

  const StudentState(this.age, this.name, this.rollNumber);
}
