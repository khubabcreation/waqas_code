import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
part 'student_event.dart';
part 'student_state.dart';

class StudentBloc extends Bloc<StudentEvent, StudentState> {
  StudentBloc() : super(const StudentState(2, "Waqas", 1222)) {
    on<NameEvent>((event, emit) => emit(const StudentState(2, "Waqas", 1222)));
    on<RollNumberEvent>(
        (event, emit) => emit(const StudentState(2, "Waqas", 1222)));
    on<AgeEvent>((event, emit) => emit(const StudentState(2, "Waqas", 1222)));
  }
}
