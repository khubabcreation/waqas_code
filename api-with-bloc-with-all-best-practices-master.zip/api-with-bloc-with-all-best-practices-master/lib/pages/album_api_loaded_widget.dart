import 'package:flutter/material.dart';

import '../api/album.dart';

class AlbumApiLoadedWidget extends StatelessWidget {
  const AlbumApiLoadedWidget({super.key, required this.list});
  final List<Album> list;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: list.length,
      itemBuilder: (context, index) {
        return ListTile(
          leading: CircleAvatar(
            child: Text(list[index].userId.toString()),
          ),
          title: Text(list[index].title),
          trailing: CircleAvatar(
            child: Text(list[index].id.toString()),
          ),
        );
      },
    );
  }
}
