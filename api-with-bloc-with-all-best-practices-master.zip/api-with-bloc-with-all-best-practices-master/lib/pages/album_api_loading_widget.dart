import 'package:flutter/material.dart';

class AlbumApiLoadingWidget extends StatelessWidget {
  const AlbumApiLoadingWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: CircularProgressIndicator(),
    );
  }
}
