import 'package:api_with_bloc_practice/bloc/album_api_bloc.dart';
import 'package:api_with_bloc_practice/main.dart';
import 'package:api_with_bloc_practice/pages/album_api_error_widget.dart';
import 'package:api_with_bloc_practice/pages/album_api_initial_widget.dart';
import 'package:api_with_bloc_practice/pages/album_api_loaded_widget.dart';
import 'package:api_with_bloc_practice/pages/album_api_loading_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'album_api_abum_loaded_widget.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late TextEditingController textController;
  @override
  void initState() {
    super.initState();
    textController = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          title: Text(widget.title),
        ),
        body: SizedBox(
          height: MediaQuery.sizeOf(context).height,
          width: MediaQuery.sizeOf(context).width,
          child: Column(children: [
            TextField(
              decoration: const InputDecoration(hintText: 'Enter User id'),
              controller: textController,
            ),
            SizedBox(
                height: MediaQuery.sizeOf(context).height * 0.8,
                width: MediaQuery.sizeOf(context).width,
                child: BlocBuilder<AlbumApiBloc, AlbumApiState>(
                  bloc: context.read<AlbumApiBloc>(),
                  builder: (context, state) {
                    if (state is AlbumApiInitialState) {
                      return const AlbumApiInitialWidget();
                    } else {
                      if (state is AlbumApiLoadingState) {
                        return const AlbumApiLoadingWidget();
                      } else {
                        if (state is AlbumsApiLoadedState) {
                          return AlbumApiLoadedWidget(
                            list: state.album,
                          );
                        } else {
                          if (state is AlbumApiLoadedState) {
                            return AlbumApiAlbumLoadedWidget(
                              album: state.album,
                            );
                          } else {
                            return const AlbumApiErrorWidget();
                          }
                        }
                      }
                    }
                  },
                ))
          ]),
        ),
        floatingActionButton: ButtonBar(
          children: [
            FloatingActionButton(
              onPressed: () {
                context.read<AlbumApiBloc>().add(FetchAlbumsEvent());
              },
              tooltip: 'Fetch All Albums',
              child: const Icon(Icons.add),
            ),
            FloatingActionButton(
              onPressed: () {
                endPoint = textController.text;
                context.read<AlbumApiBloc>().add(FetchAlbumEvent());
              },
              tooltip: 'Fetch A Album',
              child: const Icon(Icons.add),
            ),
          ],
        ));
  }
}
