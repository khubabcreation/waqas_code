import 'package:flutter/material.dart';

class AlbumApiInitialWidget extends StatelessWidget {
  const AlbumApiInitialWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Press button to get Data'),
    );
  }
}
