import 'package:flutter/material.dart';

import '../api/album.dart';

class AlbumApiAlbumLoadedWidget extends StatelessWidget {
  const AlbumApiAlbumLoadedWidget({super.key, required this.album});
  final Album album;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(child: Text(album.userId.toString())),
      title: Text(album.title),
      trailing: CircleAvatar(
        child: Text(album.id.toString()),
      ),
    );
  }
}
