import 'package:api_with_bloc_practice/api/album_api_provider.dart';
import 'package:api_with_bloc_practice/main.dart';
import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import '../api/album.dart';
part 'album_api_event.dart';
part 'album_api_state.dart';

class AlbumApiBloc extends Bloc<AlbumApiEvent, AlbumApiState> {
  final apiProvider = AlbumApiProvider();
  AlbumApiBloc() : super(AlbumApiInitialState()) {
    on<FetchAlbumsEvent>((event, emit) async {
      emit(AlbumApiLoadingState());
      try {
        List<Album> album = await apiProvider.fetchAlbums();
        emit(AlbumsApiLoadedState(album: album));
      } catch (e) {
        emit(AlbumApiErrorState(errorMessage: e.toString()));
      }
    });

    on<FetchAlbumEvent>((event, emit) async {
      emit(AlbumApiLoadingState());
      try {
        Album album = await apiProvider.fetchAlbum(endPoint: endPoint);
        emit(AlbumApiLoadedState(album: album));
      } catch (e) {
        emit(AlbumApiErrorState(errorMessage: e.toString()));
      }
    });
  }
}
