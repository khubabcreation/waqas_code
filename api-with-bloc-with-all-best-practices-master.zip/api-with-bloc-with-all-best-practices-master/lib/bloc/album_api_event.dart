part of 'album_api_bloc.dart';

@immutable
abstract class AlbumApiEvent {}

class FetchAlbumsEvent extends AlbumApiEvent {}

class FetchAlbumEvent extends AlbumApiEvent {
//  final String endPoint;
//   FetchAlbumEvent({required this.endPoint});
}
