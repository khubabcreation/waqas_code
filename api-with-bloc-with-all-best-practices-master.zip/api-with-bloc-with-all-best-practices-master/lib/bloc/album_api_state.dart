part of 'album_api_bloc.dart';

@immutable
abstract class AlbumApiState {}

class AlbumApiInitialState extends AlbumApiState {}

class AlbumApiLoadingState extends AlbumApiState {}

class AlbumsApiLoadedState extends AlbumApiState {
  final List<Album> album;
  AlbumsApiLoadedState({required this.album});
}

class AlbumApiLoadedState extends AlbumApiState {
  final Album album;
  AlbumApiLoadedState({required this.album});
}

class AlbumApiErrorState extends AlbumApiState {
  final String errorMessage;
  AlbumApiErrorState({required this.errorMessage});
}
