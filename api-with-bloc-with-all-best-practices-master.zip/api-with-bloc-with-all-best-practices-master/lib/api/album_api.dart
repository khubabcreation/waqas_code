import 'dart:convert';
import 'package:api_with_bloc_practice/api/api_status_codes.dart';
import 'package:http/http.dart' as http;

abstract class AlbumApi {
  String get baseUrl => 'https://jsonplaceholder.typicode.com/';
  String get apiUrl;

  fetch({String endPoint = ''}) async {
    var response = await http.get(Uri.parse('$baseUrl$apiUrl/$endPoint'));
    if (response.isSuccess) {
      return jsonDecode(response.body);
    } else {
      return null;
    }
  }
}
