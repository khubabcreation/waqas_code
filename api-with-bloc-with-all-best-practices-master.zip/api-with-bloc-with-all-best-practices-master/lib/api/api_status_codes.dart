import 'package:http/http.dart' as http;

extension RESTCodes on http.Response {
  bool get isSuccess => 200 == statusCode;
  bool get isCreated => 201 == statusCode;
}
