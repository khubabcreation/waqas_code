import 'package:api_with_bloc_practice/api/album_api.dart';

import 'album.dart';

class AlbumApiProvider extends AlbumApi {
  @override
  String get apiUrl => 'albums';

  Future<List<Album>> fetchAlbums() async {
    List listOfMaps = await fetch();
    return listOfMaps.map((map) => Album.fromMap(map)).toList();
  }

  Future<Album> fetchAlbum({required String endPoint}) async {
    Map<String, dynamic> map = await fetch(endPoint: endPoint);
    return Album.fromMap(map);
  }
}
