part of 'calculator_bloc.dart';

@immutable
sealed class CalculatorEvent {}

class AdditionEvent extends CalculatorEvent {
  final double a;
  final double b;
  AdditionEvent({required this.a, required this.b});
}
