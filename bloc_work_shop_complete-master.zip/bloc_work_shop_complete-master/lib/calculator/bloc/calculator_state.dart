part of 'calculator_bloc.dart';

@immutable
sealed class CalculatorState {}

final class CalculatorInitial extends CalculatorState {}

final class AdditionState extends CalculatorState {
  final double result;
  AdditionState(this.result);
}
