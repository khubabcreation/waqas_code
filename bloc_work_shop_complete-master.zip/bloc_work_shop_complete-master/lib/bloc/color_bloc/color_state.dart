part of 'color_bloc.dart';

final class ColorState {
  final Color color;
  ColorState(this.color);
}
