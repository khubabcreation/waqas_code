part of 'color_bloc.dart';

@immutable
sealed class ColorEvent {}

class ChangeColorToBlue extends ColorEvent {}

class ChangeColorToRed extends ColorEvent {}
