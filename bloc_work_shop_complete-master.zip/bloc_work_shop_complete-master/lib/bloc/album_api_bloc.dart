import 'package:bloc/bloc.dart';
import 'package:bloc_workshop/api/api_provider.dart';
import 'package:meta/meta.dart';

import '../api/album.dart';

part 'album_api_event.dart';
part 'album_api_state.dart';

class AlbumApiBloc extends Bloc<AlbumApiEvent, AlbumApiState> {
  AlbumApiBloc() : super(AlbumApiInitial()) {
    AlbumProvider albumProvider = AlbumProvider();
    on<FetchAlbumEvent>((event, emit) async {
      emit(LoadingState());
      try {
        var listOfAlbums = await albumProvider.fetchAlbums();
        emit(LoadedState(listOfAlbums: listOfAlbums));
      } catch (e) {
        emit(ErrorState(errorMessage: e.toString()));
      }
    });
  }
}
