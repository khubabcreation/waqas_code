part of 'album_api_bloc.dart';

@immutable
sealed class AlbumApiEvent {}

class FetchAlbumEvent extends AlbumApiEvent {}
