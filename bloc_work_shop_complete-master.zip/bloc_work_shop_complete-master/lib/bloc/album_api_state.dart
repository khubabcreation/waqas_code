part of 'album_api_bloc.dart';

@immutable
sealed class AlbumApiState {}

final class AlbumApiInitial extends AlbumApiState {}

final class LoadingState extends AlbumApiState {}

final class LoadedState extends AlbumApiState {
  final List<Album> listOfAlbums;
  LoadedState({required this.listOfAlbums});
}

final class ErrorState extends AlbumApiState {
  final String errorMessage;
  ErrorState({required this.errorMessage});
}
