import 'package:bloc_workshop/calculator/bloc/calculator_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key});

  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  late TextEditingController textEditingControllerForFirstNumber;
  late TextEditingController textEditingControllerForSecondNumber;

  @override
  void initState() {
    textEditingControllerForFirstNumber = TextEditingController();
    textEditingControllerForSecondNumber = TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculator'),
      ),
      body: Column(children: [
        TextField(
          controller: textEditingControllerForFirstNumber,
          decoration: const InputDecoration(hintText: 'Enter first Number'),
        ),
        TextField(
          controller: textEditingControllerForSecondNumber,
          decoration: const InputDecoration(hintText: 'Enter second  Number'),
        ),
        //
        BlocBuilder<CalculatorBloc, CalculatorState>(
            // bloc: calculatorBloc,
            builder: (context, state) {
          if (state is CalculatorInitial) {
            return const Text('Get Something');
          } else {
            double result = (state as AdditionState).result;
            return Text(result.toString());
          }
        }),
        ElevatedButton(
            onPressed: () {
              context.read<CalculatorBloc>().add(AdditionEvent(
                  a: double.parse(textEditingControllerForFirstNumber.text),
                  b: double.parse(
                      textEditingControllerForSecondNumber.text.toString())));
            },
            child: const Text('Add them'))
      ]),
    );
  }
}
