import 'package:bloc_workshop/bloc/album_api_bloc.dart';
import 'package:bloc_workshop/calculator/bloc/calculator_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'bloc/color_bloc/color_bloc.dart';
import 'bloc/counter_bloc.dart';
import 'calculator.dart';

void main() {
  runApp(const MyApp());
}


class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<CounterBloc>(
          create: (context) => CounterBloc(),
        ),
        BlocProvider<ColorBloc>(
          create: (context) => ColorBloc(),
        ),
        BlocProvider<AlbumApiBloc>(
          create: (context) => AlbumApiBloc(),
        ),
        BlocProvider<CalculatorBloc>(
          create: (context) => CalculatorBloc(),
        )
      ],
      child: MaterialApp(
          theme: ThemeData(
            colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
            useMaterial3: true,
          ),
          home: const MyHomePage(title: 'Flutter Demo Home Page')),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late TextEditingController textEditingControllerForFirstNumber;
  late TextEditingController textEditingControllerForSecondNumber;

  @override
  void initState() {
    textEditingControllerForFirstNumber = TextEditingController();
    textEditingControllerForSecondNumber = TextEditingController();
    super.initState();
  }

  void _incrementCounter() {
    context.read<CounterBloc>().add(IncrementEvent());
  }

  void _decrementCounter() {
    context.read<CounterBloc>().add(DecrementEvent());
  }

  void changeColorToRed() {
    context.read<ColorBloc>().add(ChangeColorToRed());
  }

  void changeColorToBlue() {
    context.read<ColorBloc>().add(ChangeColorToBlue());
  }

  void getAlbum() {
    context.read<AlbumApiBloc>().add(FetchAlbumEvent());
  }

  @override
  Widget build(BuildContext context) {
    print('Build method of  called');

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            BlocBuilder<CounterBloc, CounterState>(
              builder: (context, state) {
                print('Build of counter called');
                return Text(
                  '${state.count}',
                  style: Theme.of(context).textTheme.headlineMedium,
                );
              },
            ),
            BlocBuilder<ColorBloc, ColorState>(
              builder: (context, state) {
                print('Build of color called');

                return Container(height: 100, width: 100, color: state.color);
              },
            ),
            ElevatedButton(
                onPressed: () {
                  _incrementCounter();
                  changeColorToRed();
                },
                child: const Text('Increment')),
            ElevatedButton(
                onPressed: () {
                  _decrementCounter();
                  changeColorToBlue();
                },
                child: const Text('Decrement')),
            SizedBox(
              height: 100,
              child: BlocBuilder<AlbumApiBloc, AlbumApiState>(
                builder: (context, state) {
                  if (state is AlbumApiInitial) {
                    return const Text('Click to load data');
                  } else {
                    if (state is LoadingState) {
                      return const CircularProgressIndicator();
                    } else {
                      if (state is LoadedState) {
                        return ListView.builder(
                          itemCount: state.listOfAlbums.length,
                          itemBuilder: (context, index) {
                            return ListTile(
                              leading:
                                  Text(state.listOfAlbums[index].id.toString()),
                              title: Text(state.listOfAlbums[index].title),
                              trailing:
                                  Text(state.listOfAlbums[index].id.toString()),
                            );
                          },
                        );
                      } else {
                        String error = (state as ErrorState).errorMessage;
                        return Text(error);
                      }
                    }
                  }
                },
              ),
            ),
            ElevatedButton(
                onPressed: getAlbum, child: const Text('Fetch Data')),
            TextField(
              controller: textEditingControllerForFirstNumber,
              decoration: const InputDecoration(hintText: 'Enter first Number'),
            ),
            TextField(
              controller: textEditingControllerForSecondNumber,
              decoration:
                  const InputDecoration(hintText: 'Enter second  Number'),
            ),
            BlocBuilder<CalculatorBloc, CalculatorState>(
                builder: (context, state) {
              if (state is CalculatorInitial) {
                return const Text('Get Something');
              } else {
                double result = (state as AdditionState).result;
                return Text(result.toString());
              }
            }),
            BlocConsumer<CalculatorBloc, CalculatorState>(

              listener: (context, state) {
                // TODO: implement listener
              },
              builder: (context, state) {
                return Container();
              },
            )
            ElevatedButton(
                onPressed: () {
                  context.read<CalculatorBloc>();
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) {
                      return const CalculatorPage();
                    },
                  ));
                },
                child: const Text('Go To Next Page')),
          ],
        ),
      ),
    );
  }
}
